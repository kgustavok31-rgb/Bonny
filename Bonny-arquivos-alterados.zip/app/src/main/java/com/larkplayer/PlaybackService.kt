package com.larkplayer

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Owns the player independently from the activity so audio can continue while
 * the UI is backgrounded. MediaSessionService exposes standard Android media
 * controls and the notification for the active session.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val player = ExoPlayer.Builder(this)
            // Let ExoPlayer request/release audio focus and pause appropriately
            // when calls, other apps, or system audio take focus.
            .setAudioAttributes(audioAttributes, true)
            // Pause playback when headphones or another output device disconnects.
            .setHandleAudioBecomingNoisy(true)
            .build()

        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.let { mediaSession ->
            mediaSession.player.release()
            mediaSession.release()
        }
        session = null
        super.onDestroy()
    }
}

package com.larkplayer

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val store = PlaylistStore(app)
    private val lib = LibraryStore(app)
    private var lastLogged: String? = null
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var pendingPlayback: Pair<List<Song>, Int>? = null

    var songs by mutableStateOf(listOf<Song>()); private set
    var playlists by mutableStateOf(store.load()); private set
    var recents by mutableStateOf(lib.recents()); private set
    var favorites by mutableStateOf(lib.favorites()); private set
    var currentId by mutableStateOf<String?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var isBuffering by mutableStateOf(false); private set
    var playerError by mutableStateOf<String?>(null); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableStateOf(Player.REPEAT_MODE_OFF); private set
    var position by mutableLongStateOf(0L); private set
    var duration by mutableLongStateOf(0L); private set

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)

        override fun onPlaybackStateChanged(playbackState: Int) {
            isBuffering = playbackState == Player.STATE_BUFFERING
            if (playbackState == Player.STATE_READY) playerError = null
        }

        override fun onPlayerError(error: PlaybackException) {
            isPlaying = false
            isBuffering = false
            playerError = when (error.errorCode) {
                PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "O arquivo desta música não foi encontrado."
                PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> "O Android não permitiu acessar este arquivo."
                else -> "Não foi possível reproduzir esta música. Tente outra faixa."
            }
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val connected = future.get()
                if (isCleared) {
                    connected.release()
                    return@addListener
                }
                controller = connected
                connected.addListener(listener)
                sync(connected)
                val pending = pendingPlayback
                pendingPlayback = null
                if (pending != null) play(pending.first, pending.second)
            } catch (_: Exception) {
                playerError = "Não foi possível iniciar o reprodutor. Feche e abra o aplicativo novamente."
            }
        }, ContextCompat.getMainExecutor(app))
    }

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        isBuffering = p.playbackState == Player.STATE_BUFFERING
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        val id = p.currentMediaItem?.mediaId
        currentId = id
        if (id != null && id != lastLogged) {
            lastLogged = id
            id.toLongOrNull()?.let { addRecent(it) }
        }
        refresh()
    }

    fun refresh() {
        val c = controller ?: return
        position = c.currentPosition.coerceAtLeast(0L)
        duration = c.duration.takeIf { it != C.TIME_UNSET }?.coerceAtLeast(0L) ?: 0L
    }

    fun loadSongs() {
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) { MusicRepository.load(getApplication()) }
            songs = loaded
        }
    }

    fun play(list: List<Song>, index: Int) {
        if (list.isEmpty() || index !in list.indices) return
        val c = controller
        if (c == null) {
            pendingPlayback = list.toList() to index
            return
        }
        playerError = null
        val items = list.map {
            MediaItem.Builder().setMediaId(it.id.toString()).setUri(it.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(it.title)
                        .setArtist(it.artist)
                        .setAlbumTitle(it.album)
                        .build()
                ).build()
        }
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
    }

    fun playPlaylist(p: Playlist) {
        val list = p.ids.mapNotNull { id -> songs.find { it.id == id } }
        if (list.isNotEmpty()) play(list, 0)
    }

    fun togglePlay() {
        controller?.let { player ->
            playerError = null
            if (player.isPlaying || player.playWhenReady) player.pause() else {
                if (player.mediaItemCount > 0) player.play()
            }
        }
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) {
        val safePosition = ms.coerceAtLeast(0L).let { if (duration > 0) it.coerceAtMost(duration) else it }
        controller?.seekTo(safePosition)
        position = safePosition
    }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun createPlaylist(name: String) {
        val cleanName = name.trim()
        if (cleanName.isBlank() || playlists.any { it.name.equals(cleanName, ignoreCase = true) }) return
        playlists = playlists + Playlist(cleanName, emptyList())
        store.save(playlists)
    }

    fun addToPlaylist(name: String, songId: Long) {
        playlists = playlists.map {
            if (it.name == name && songId !in it.ids) it.copy(ids = it.ids + songId) else it
        }
        store.save(playlists)
    }

    fun deletePlaylist(name: String) {
        playlists = playlists.filterNot { it.name == name }
        store.save(playlists)
    }

    private fun addRecent(id: Long) {
        recents = (listOf(id) + recents.filter { it != id }).take(20)
        lib.saveRecents(recents)
    }

    fun toggleFavorite(id: Long) {
        favorites = if (id in favorites) favorites - id else favorites + id
        lib.saveFavorites(favorites)
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        controllerFuture?.cancel(false)
        controllerFuture = null
        super.onCleared()
    }
}

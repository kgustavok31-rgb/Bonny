# Bonny — refinamentos da reprodução

Este pacote contém somente os arquivos alterados, mantendo os caminhos relativos do projeto original.

## Arquivos incluídos
- `app/src/main/java/com/larkplayer/PlayerViewModel.kt`
- `app/src/main/java/com/larkplayer/PlaybackService.kt`
- `app/src/main/java/com/larkplayer/Ui.kt`
- `app/build.gradle.kts`

## O que mudou
- Carregamento da biblioteca de áudio fora da thread principal.
- Tratamento de conexão assíncrona do MediaController e de reprodução solicitada antes da conexão.
- Tratamento de erros de reprodução com mensagem na interface.
- Estado de buffering visível no mini player.
- Busca na linha do tempo com pré-visualização durante o arrasto e seek ao terminar.
- Validação básica do nome de playlist para evitar nomes vazios ou duplicados.
- Configuração explícita de atributos de áudio e tratamento de perda de foco/desconexão de fones.
- Dependência `lifecycle-viewmodel-ktx` para `viewModelScope`.

## Como aplicar
1. Faça uma cópia de segurança do seu projeto.
2. Extraia este ZIP na raiz do projeto, aceitando substituir os arquivos.
3. Sincronize o Gradle e compile pelo Android Studio.

O pacote não inclui um APK. Não foi possível executar uma compilação Gradle neste ambiente porque o projeto enviado não inclui `gradlew` e não há instalação local do Gradle disponível aqui. Por isso, compile no Android Studio e envie qualquer erro de compilação para eu corrigir.

# Registro da análise estática do Lark Player

Arquivo de entrada: `Lark Player_2026.16.5.apks`.

## Conteúdo observado

- Bundle ZIP contendo `info.json`, `icon.png`, `base.apk`, `split_config.arm64_v8a.apk` e `split_config.xhdpi.apk`.
- Metadados de `info.json`: pacote `com.dywx.larkplayer`, versão `2026.16.5`, código `2026160509`, `min_sdk` 25 e `target_sdk` 36.
- O `base.apk` contém múltiplos DEX e recursos Android. A inspeção superficial de strings encontrou referências a AndroidX Media3/ExoPlayer, `android.media.audiofx.Equalizer`, letras sincronizadas e campos típicos de uma biblioteca musical (título, artista, álbum, favoritos, contagem de reprodução e caminhos).
- Foi observada referência à permissão `READ_MEDIA_AUDIO`.

## Limites e uso

Esta análise foi feita por inspeção de estrutura e strings. Não houve decompilação completa de Java/Kotlin, execução do aplicativo, interceptação de tráfego ou teste de comportamento. Portanto, não se deve tratar este relatório como uma especificação completa do produto original.

O Bonny Player é um projeto independente que reimplementa funções comuns de um reprodutor local usando bibliotecas públicas do Android. Nenhum código-fonte descompilado do Lark Player foi incorporado deliberadamente.

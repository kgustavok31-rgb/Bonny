# Bonny Player

Player de música local para Android, independente, feito em Kotlin, Jetpack Compose, Material 3 e AndroidX Media3. A interface usa padrões familiares do Android/Material You e toma o Lark Player apenas como referência visual/funcional — não incorpora código proprietário extraído dele.

## O que já está implementado

- Leitura da biblioteca de áudio local pelo `MediaStore` e solicitação de permissão conforme a versão do Android.
- Busca por título, artista e álbum.
- Navegação entre Músicas, Álbuns e Favoritos.
- Favoritos persistidos localmente.
- Reprodução, pausa, faixa anterior/próxima e fila com a biblioteca carregada.
- Serviço Media3 com sessão de mídia para reprodução em segundo plano e integração com os controles de mídia do Android.
- Cores dinâmicas Material You no Android 12 ou superior.
- GitHub Actions para compilar o APK de debug e publicá-lo como artefato da execução.

## Gerar o APK sem Android Studio

1. Baixe e extraia este ZIP.
2. Crie um repositório vazio no GitHub e envie **o conteúdo da pasta `BonnyPlayer`** para a branch `main`.
3. Abra **Actions** no repositório e execute **Build Bonny Player APK** (ou faça um push para `main`).
4. Abra a execução concluída e baixe o artefato `Bonny-Player-debug`.
5. Extraia o artefato para obter `app-debug.apk` e instale-o no Android.

O workflow também pode ser executado manualmente em **Actions → Build Bonny Player APK → Run workflow**.

## Ambiente técnico

- Android: `minSdk 25`, `targetSdk 35`, `compileSdk 35`.
- Kotlin 2.0.21, Android Gradle Plugin 8.9.2.
- Jetpack Compose + Material 3.
- AndroidX Media3/ExoPlayer 1.5.1.

## Limitações desta versão

Esta é uma primeira versão funcional do projeto, não uma reprodução integral do Lark Player. Capas reais dos álbuns, tela de reprodução expandida, playlists editáveis, letras sincronizadas, equalizador e preferências avançadas ainda não foram implementados. A compilação e os testes em aparelho precisam ser confirmados pela execução do GitHub Actions e por teste real; não afirmamos que o APK já foi validado.

## Análise estática do pacote de referência

O pacote enviado foi um bundle `.apks` com `base.apk` e splits de arquitetura/densidade. A inspeção preliminar identificou referências a AndroidX Media3/ExoPlayer, `android.media.audiofx.Equalizer`, permissões de acesso à biblioteca de áudio e textos relacionados a letras. Isso é análise estática superficial de metadados e strings; não equivale a decompilação completa, análise dinâmica ou auditoria de todas as funções.

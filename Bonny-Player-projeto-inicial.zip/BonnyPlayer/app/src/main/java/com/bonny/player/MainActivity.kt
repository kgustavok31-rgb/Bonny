package com.bonny.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

private const val PREFS = "bonny_player"
private const val FAVORITES_KEY = "favorite_ids"

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val uri: Uri
)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller by mutableStateOf<MediaController?>(null)
    private var songs by mutableStateOf<List<Song>>(emptyList())
    private var permissionGranted by mutableStateOf(false)
    private var isPlaying by mutableStateOf(false)
    private var currentTitle by mutableStateOf("Escolha uma música")
    private var favoriteIds by mutableStateOf<Set<Long>>(emptySet())

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentTitle = mediaItem?.mediaMetadata?.title?.toString() ?: "Escolha uma música"
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) loadSongs()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        favoriteIds = getSharedPreferences(PREFS, MODE_PRIVATE).getStringSet(FAVORITES_KEY, emptySet())
            .orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
        permissionGranted = hasAudioPermission()
        if (permissionGranted) loadSongs() else permissionLauncher.launch(audioPermission())

        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(playerListener)
                controller?.let {
                    isPlaying = it.isPlaying
                    currentTitle = it.currentMediaItem?.mediaMetadata?.title?.toString() ?: "Escolha uma música"
                }
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))

        setContent {
            BonnyTheme {
                BonnyHome(
                    songs = songs,
                    favoriteIds = favoriteIds,
                    currentTitle = currentTitle,
                    isPlaying = isPlaying,
                    permissionGranted = permissionGranted,
                    onSongClick = ::play,
                    onToggleFavorite = ::toggleFavorite,
                    onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                    onNext = { controller?.seekToNextMediaItem() },
                    onPrevious = { controller?.seekToPreviousMediaItem() },
                    onRequestPermission = { permissionLauncher.launch(audioPermission()) }
                )
            }
        }
    }

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, audioPermission()) == PackageManager.PERMISSION_GRANTED

    private fun loadSongs() {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val found = mutableListOf<Song>()
        contentResolver.query(
            collection, projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol)?.takeUnless { it.isBlank() } ?: "Faixa sem título"
                val artist = cursor.getString(artistCol)?.takeUnless { it.isBlank() || it == "<unknown>" } ?: "Artista desconhecido"
                val album = cursor.getString(albumCol)?.takeUnless { it.isBlank() || it == "<unknown>" } ?: "Álbum desconhecido"
                found += Song(id, title, artist, album, cursor.getLong(albumIdCol), ContentUris.withAppendedId(collection, id))
            }
        }
        songs = found
    }

    private fun toggleFavorite(song: Song) {
        favoriteIds = if (song.id in favoriteIds) favoriteIds - song.id else favoriteIds + song.id
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putStringSet(FAVORITES_KEY, favoriteIds.map { it.toString() }.toSet()).apply()
    }

    private fun play(song: Song) {
        val c = controller ?: return
        val items = songs.map { s ->
            MediaItem.Builder()
                .setMediaId(s.id.toString())
                .setUri(s.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album).build())
                .build()
        }
        val index = songs.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
    }

    override fun onDestroy() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}

@Composable
private fun BonnyTheme(content: @Composable () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicLightColorScheme(context) else lightColorScheme()
    MaterialTheme(colorScheme = scheme, content = content)
}

private enum class LibraryTab(val label: String) { SONGS("Músicas"), ALBUMS("Álbuns"), FAVORITES("Favoritos") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BonnyHome(
    songs: List<Song>,
    favoriteIds: Set<Long>,
    currentTitle: String,
    isPlaying: Boolean,
    permissionGranted: Boolean,
    onSongClick: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onRequestPermission: () -> Unit
) {
    var tab by remember { mutableStateOf(LibraryTab.SONGS) }
    var query by remember { mutableStateOf("") }
    val filtered = remember(songs, favoriteIds, query, tab) {
        songs.filter { song ->
            val matchesQuery = listOf(song.title, song.artist, song.album).any { it.contains(query.trim(), ignoreCase = true) }
            val matchesTab = when (tab) {
                LibraryTab.SONGS -> true
                LibraryTab.ALBUMS -> true
                LibraryTab.FAVORITES -> song.id in favoriteIds
            }
            matchesQuery && matchesTab
        }
    }
    val albums = remember(filtered) { filtered.distinctBy { it.albumId }.sortedBy { it.album.lowercase() } }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("Bonny Player", style = MaterialTheme.typography.titleLarge)
                    Text("Sua música, do seu jeito", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            })
        },
        bottomBar = {
            NavigationBar {
                LibraryTab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(when (item) { LibraryTab.SONGS -> Icons.Default.MusicNote; LibraryTab.ALBUMS -> Icons.Default.Album; LibraryTab.FAVORITES -> Icons.Default.Favorite }, contentDescription = null) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(8.dp))
            Text(when (tab) { LibraryTab.SONGS -> "Sua biblioteca"; LibraryTab.ALBUMS -> "Seus álbuns"; LibraryTab.FAVORITES -> "Suas favoritas" }, style = MaterialTheme.typography.headlineMedium)
            Text("${songs.size} músicas no dispositivo", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("Buscar música, artista ou álbum") },
                shape = RoundedCornerShape(18.dp)
            )
            Spacer(Modifier.height(8.dp))
            if (!permissionGranted || songs.isEmpty()) {
                ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(44.dp))
                        Spacer(Modifier.height(8.dp))
                        Text(if (!permissionGranted) "Permita o acesso às músicas para começar" else "Nenhuma música encontrada no dispositivo")
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = onRequestPermission) { Text("Permitir acesso") }
                    }
                }
            } else if (tab == LibraryTab.ALBUMS) {
                LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                    items(albums, key = { it.albumId }) { album ->
                        Row(Modifier.fillMaxWidth().clickable { onSongClick(album) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AlbumTile()
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(album.album, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                                Text(album.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Default.PlayArrow, contentDescription = "Reproduzir álbum")
                        }
                    }
                }
            } else {
                val list = filtered
                if (list.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(if (tab == LibraryTab.FAVORITES) "Adicione músicas aos favoritos usando o coração." else "Nenhum resultado para essa busca.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                        items(list, key = { it.id }) { song ->
                            Row(Modifier.fillMaxWidth().clickable { onSongClick(song) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                AlbumTile()
                                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                                    Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                                }
                                IconButton(onClick = { onToggleFavorite(song) }) {
                                    Icon(if (song.id in favoriteIds) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = if (song.id in favoriteIds) "Remover dos favoritos" else "Adicionar aos favoritos", tint = if (song.id in favoriteIds) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { onSongClick(song) }) { Icon(Icons.Default.PlayArrow, contentDescription = "Reproduzir ${song.title}") }
                            }
                        }
                    }
                }
            }
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Text("TOCANDO AGORA", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(currentTitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, contentDescription = "Anterior") }
                        FilledIconButton(onClick = onPlayPause) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (isPlaying) "Pausar" else "Reproduzir") }
                        IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, contentDescription = "Próxima") }
                    }
                }
            }
        }
    }
}

@Composable
private fun AlbumTile() {
    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(14.dp), modifier = Modifier.size(52.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
        }
    }
}
